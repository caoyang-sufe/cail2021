- 获得JEC-QA.zip压缩包并解压到当前文件夹

- 获取途径：
  1. [jecqa官网](https://jecqa.thunlp.org/readme)
  2. [百度云网盘](链接: https://pan.baidu.com/s/1vDvklLaFFqNtT7T9-mZ0iw)，提取码: s3u5